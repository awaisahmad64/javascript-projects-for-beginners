// inilizatied and decaralared a empty array here
var myName = [];
// unshift mutiple character in myName array
myName.unshift('A','W','A','I','S');
console.log(myName);