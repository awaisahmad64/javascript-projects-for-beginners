// inilizatied and decaralared a empty array here
var myName = ['A','W','A','I','S'];
// reverse the array
myName.reverse();
console.log(myName);