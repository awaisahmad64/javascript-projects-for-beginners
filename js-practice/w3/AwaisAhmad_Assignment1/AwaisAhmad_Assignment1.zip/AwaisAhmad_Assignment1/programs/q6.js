// initializing and decalaring first varible a
var a = 10;
// initializing and decalaring second variable b
var b = 5;
// adding variables a and b with log
console.log("a + b= ",a+b);
// subtracting variables a and b with log
console.log("a - b= ",a-b);
// multipling variables a and b with log
console.log("a * b= ",a*b);
// getting mod variables a and b with log
console.log("a / b= ",a/b);