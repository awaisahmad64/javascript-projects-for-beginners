// decalared a array with elements 1 to 5
var a = [1,2,3,4,5];
// log with typeof  array 
console.log('Type of a varible is : ' + typeof(a));
// initialized and decalared a bolean variable
var b = true; 
// log with typeof 
console.log('Type of b varible is : ' +typeof(b));
// initialized and decalared a string variable
var c = 'Awais'; 
// log with typeof 
console.log('Type of c varible is : ' +typeof(c));
// initialized and decalared a number variable
var d = 125; 
// log with typeof 
console.log('Type of d varible is : ' +typeof(d));
// initialized and decalared a object variable
var e = {'firstName': 'Awais'}; 
// log with typeof 
console.log('Type of e varible is : ' +typeof(e));