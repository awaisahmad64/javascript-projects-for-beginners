// inilizatied and decaralared a empty array here
var myName = [];
// push mutiple character in myName array
myName.push('A','W','A','I','S');
console.log(myName);