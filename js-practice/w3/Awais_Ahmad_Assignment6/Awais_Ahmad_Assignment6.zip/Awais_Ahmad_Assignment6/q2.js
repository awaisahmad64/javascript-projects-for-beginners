var table = 6;
var count = 5;
let i = table;
while(i <= table){
    let j = 1;
    while(j <= count){
        console.log(table + ' * ' + j + ' = ' + table * j);
        j++
    }
    i++
}