var table = 6;
var count = 5;
for (let i = table; i <= table; i++) {
  for (let j = 1; j <= count; j++) {
    console.log(table + ' * ' + j + ' = ' + table * j);
  }
}
