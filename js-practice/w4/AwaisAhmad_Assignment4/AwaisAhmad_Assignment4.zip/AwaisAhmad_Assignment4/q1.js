var arr = [1,2,3,4,5,6,7];
for( let i = 0; i < arr.length; i++){
    console.log(arr[i]);
}